#!/usr/bin/python

import pigpio
import time
import sys
import struct

if len(sys.argv) == 1: sys.argv[1:] = ["-h"]

if (len(sys.argv) - 1) % 2 != 0:
   print("Input arguments needs to follow paramN paramN+1.....");
   sys.exit();

bus = 1;
address = 0x04;

pi = pigpio.pi();
handle = pi.i2c_open(bus, address, 0);
print("Handle", handle);

for x in range(0, (len(sys.argv) - 1) // 2):
   send = 2 * [0];
   index = x*2 + 1;
   send[0] = 0;
   send[1] = int(sys.argv[index]);
   pi.i2c_write_device(handle, send);
   print("Read Param: R/W: {0} Param: {1}".format(send[0], send[1]));
   time.sleep(0.15);
   (count, data) = pi.i2c_read_device(handle, 4);
   print(data);
   typeFormat = sys.argv[index+1];
   print("In reply: {0}".format(struct.unpack(typeFormat, data)[0]));

pi.i2c_close(handle);
pi.stop();
