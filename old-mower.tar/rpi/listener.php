<?php

$handle = popen("./mower-serial-listener.out 2>&1", "r");
while(($data = fgets($handle)) !== false){
	$json = json_decode($data, true);
	var_dump($json);
}
