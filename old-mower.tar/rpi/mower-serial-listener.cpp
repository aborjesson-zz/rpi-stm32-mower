// Copyright Victor Hurdugaci (http://victorhurdugaci.com). All rights reserved.
// Licensed under the Apache License, Version 2.0. See LICENSE in the project root for license information.

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <time.h>
#include <stdint.h>
#include <string.h>
#include <cstdlib>

// Change the device, if needed
#define SERIAL_DEVICE "/dev/serial0"

#define DEBUG 1
#define MOWER_STATUS_STRUCT_ACTIONS_FIFO_ROWS 5

struct MowerStatusStruct
{
    uint8_t     mode;
    uint8_t     navigationMode;
    uint8_t     cuttingMotorForward;
    uint8_t     cuttingMotorReverse;
    uint8_t     driveMotorLeftForward;
    uint8_t     driveMotorLeftReverse;
    uint8_t     driveMotorRightForward;
    uint8_t     driveMotorRightReverse;
    float       vcc;
    float       currentDriveMotors;
    float       currentCutterMotor;
    float       magHeading;
    uint8_t     gpsStatus;
    float       gpsLongitude;
    float       gpsLatitude;
    float       gpsSpeed;
    uint16_t    loopTimeAvg;
    uint8_t     actionsParameterFIFO[MOWER_STATUS_STRUCT_ACTIONS_FIFO_ROWS];
    uint8_t     actionsValueFIFO[MOWER_STATUS_STRUCT_ACTIONS_FIFO_ROWS];

} __attribute__((packed)) mowerStatus;

int main() 
{
    int serial = open(
        SERIAL_DEVICE, 
        O_RDONLY | O_NOCTTY | O_NDELAY);
 
    if (serial == -1) 
    {
        printf("Failed to open serial port.\n");
        return -1;  
    }

    // Serial is available so let's configure it
    // All configuration options and explanations here:
    // http://linux.die.net/man/3/termios
    struct termios options;
    tcgetattr(serial, &options);
    options.c_cflag = B115200 | CS8 | CLOCAL | CREAD;
    options.c_iflag = IGNPAR;
    options.c_oflag = 0;
    options.c_lflag = 0;
    tcflush(serial, TCIFLUSH);
    tcsetattr(serial, TCSANOW, &options);

    uint8_t payloadSize = sizeof(mowerStatus);
    uint8_t telegramSize = payloadSize + 3; // HEADER (1 byte) + BYTECOUNT (1 byte) + BODY (n bytes) + CHECKSUM (1 byte)

    uint8_t byteCount = 0;
    uint8_t checkSum = 0;
    uint8_t *inputBuffer = (uint8_t*) malloc(payloadSize);
    uint8_t *ptr = (uint8_t*) &mowerStatus;
    ssize_t s = 0; unsigned char data;

    while(1){

        if((s = read(serial, &data, 1)) != -1) {
            if(byteCount == 0) {
                if(data == 'T') { //Start byte received
                    byteCount++;
                }

                continue;
            }
            else if(byteCount == 1) {
                if(payloadSize != data) {
                    if(DEBUG) printf("Payload size doesnt match. In Telegram:%d, Struct size: %d:\n", data, payloadSize);
                    byteCount = 0;

                    continue;
                }
                checkSum = data;
                byteCount++;

                continue;
            }
            else if(byteCount == (telegramSize - 1)) {
                byteCount = 0;
                if(data != checkSum) {
                    if(DEBUG) printf("Checksum doesnt match. Got %d:, Calculated %d:\n", data, checkSum);

                    continue;
                }

                memcpy(ptr, inputBuffer, payloadSize);
                
                printf("{\"mode\":%i,"
                    "\"navigationMode\":%i,"
                    "\"cuttingMotorForward\":%i,"
                    "\"cuttingMotorReverse\":%i,"
                    "\"driveMotorLeftForward\":%i,"
                    "\"driveMotorLeftReverse\":%i,"
                    "\"driveMotorRightForward\":%i,"
                    "\"driveMotorRightReverse\":%i,"
                    "\"vcc\":%f,"
                    "\"currentDriveMotors\":%f,"
                    "\"currentCutterMotor\":%f,"
                    "\"magHeading\":%f,"
                    "\"gpsStatus\":%i,"
                    "\"gpsLongitude\":%f,"
                    "\"gpsLatitude\":%f,"
                    "\"gpsSpeed\":%f,"
                    "\"loopTimeAvg\":%d,",
                    mowerStatus.mode,
                    mowerStatus.navigationMode,
                    mowerStatus.cuttingMotorForward,
                    mowerStatus.cuttingMotorReverse,
                    mowerStatus.driveMotorLeftForward,
                    mowerStatus.driveMotorLeftReverse,
                    mowerStatus.driveMotorRightForward,
                    mowerStatus.driveMotorRightReverse,
                    mowerStatus.vcc,
                    mowerStatus.currentDriveMotors,
                    mowerStatus.currentCutterMotor,
                    mowerStatus.magHeading,
                    mowerStatus.gpsStatus,
                    mowerStatus.gpsLongitude,
                    mowerStatus.gpsLatitude,
                    mowerStatus.gpsSpeed,
                    mowerStatus.loopTimeAvg);

                printf("\"actionsFIFO\":[");
                for (int i = 0; i < MOWER_STATUS_STRUCT_ACTIONS_FIFO_ROWS; i++)
                {
                    if(mowerStatus.actionsParameterFIFO[i] > 0) {
                        printf("{\"parameter\":%i,\"value\":%i}", mowerStatus.actionsParameterFIFO[i], mowerStatus.actionsValueFIFO[i]);
                        
                        if(MOWER_STATUS_STRUCT_ACTIONS_FIFO_ROWS > (i+1) && mowerStatus.actionsParameterFIFO[i+1] > 0)
                            printf(",");
                    }
                }
                printf("]");

                printf("}\r\n");

                fflush(stdout);
                continue;
            }

            // ByteCount will be two before we get the real message
            inputBuffer[byteCount - 2] = data;
            checkSum ^= data;
            byteCount++;
            usleep(1000);
        }   else    {
            sleep(1);
        }
    }

    close(serial);
    return 0;
}
