// Copyright Victor Hurdugaci (http://victorhurdugaci.com). All rights reserved.
// Licensed under the Apache License, Version 2.0. See LICENSE in the project root for license information.

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <time.h>
#include <stdint.h>
#include <string.h>
#include <cstdlib>

// Change the device, if needed
#define SERIAL_DEVICE "/dev/serial0"

#define DEBUG 1

struct SetParameterStruct
{
    uint8_t     parameter;
    uint8_t     value;
} setParameter;

void sendProtocolToArduino(int serial, uint8_t* protocol, uint8_t payloadSize) {

    unsigned char header = 'T';
    
    uint8_t buffer[payloadSize];
    uint8_t checksum = payloadSize;
    uint8_t i;
    
    for(i = 0; i < payloadSize; i++) {
        buffer[i] = *(protocol+i);
        checksum ^= buffer[i];
    }

    write(serial, &header, 1);
    write(serial, &payloadSize, 1);
    write(serial, &buffer, payloadSize);
    write(serial, &checksum, 1);
}

int main(int argc, char **argv)
{
    int serial = open(
        SERIAL_DEVICE, 
        O_RDWR | O_NOCTTY | O_NDELAY);
 
    if (serial == -1) 
    {
        printf("Failed to open serial port.\n");
        return -1;  
    }

    // Serial is available so let's configure it
    // All configuration options and explanations here:
    // http://linux.die.net/man/3/termios
    struct termios options;
    tcgetattr(serial, &options);
    options.c_cflag = B115200 | CS8 | CLOCAL | CREAD;
    options.c_iflag = IGNPAR;
    options.c_oflag = 0;
    options.c_lflag = 0;
    tcflush(serial, TCIFLUSH);
    tcsetattr(serial, TCSANOW, &options);

    for (int i = 1; i < argc; i += 2)
    {
        setParameter.parameter = atoi(argv[i]);
        setParameter.value = atoi(argv[i+1]);
        sendProtocolToArduino(serial, (uint8_t*) &setParameter, sizeof(setParameter));
        printf("Param %d Val %d\n", atoi(argv[i]), atoi(argv[i+1]));
        usleep(100);
    }

    close(serial);
    return 0;
}
